import glob

# folder path containing mlp_*.bin
input_folder = "./"
output_file = "./mlp_all_hex.txt"

with open(output_file, "w") as out:
    for filename in sorted(glob.glob(f"{input_folder}mlp_*.bin")):
        with open(filename, "rb") as f:
            hex_data = f.read().hex()
            out.write(hex_data + "\n")

print("✅ Done! Combined all MLP hex data into mlp_all_hex.txt")
